# NexaFlow Distribution ERP — GitHub-ready files

## Files
- `index.html` — page structure and CDN dependencies
- `styles.css` — application styles extracted from the original HTML
- `app.js` — application JavaScript extracted from the original HTML

## Deploy on GitHub Pages
1. Create/open your GitHub repository.
2. Upload these three files into the repository root (same folder).
3. Commit changes.
4. In **Settings → Pages**, choose deployment from the branch and root folder.
5. Open the generated Pages URL.

## Important
- Keep all three files together in the same directory.
- The app uses CDN libraries for XLSX and PDF features, so those features need internet access.
- This is a file-structure split only; business logic was not intentionally rewritten.
- Before replacing a live ERP, keep a backup and test sales, purchases, stock, recovery, reports, and printing.
- Firebase/client-side configuration, if enabled in the app, must be secured with appropriate Firebase rules and API-key restrictions.
